
import java.util.Comparator;


/**
 * Compares Players based on their ranks
 * 
 * @author daan
 */
public class RankComparator implements Comparator<Player> {
  
  public int compare(Player a, Player b) {
    if(a.getRank() < b.getRank()) {
      return -1;
    } else if (a.getRank() > b.getRank()) {
      return 1;
    } else {
      return 0;
    }
  }
}
