
/**
 *
 * @author daan
 */
public class Simulation {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    // Create a new game
    Game pewpew = new Game();
    
    // Create some players...
    Player daan = new Player("Daan");
    Player youri = new Player("Youri");
    Player tim = new Player("Tim");
    Player jellis = new Player("Jellis");
    Player daniel = new Player("Daniel");
    
    //...and add them to the game
    pewpew.addPlayer(daan);
    pewpew.addPlayer(youri);
    pewpew.addPlayer(tim);
    pewpew.addPlayer(jellis);
    pewpew.addPlayer(daniel);
    
    // Let's check if we're all there, incl begin-rankings
    System.out.println("PLAYERS PRESENT IN THIS GAME:");
    for(Player p : pewpew.getRankedPlayers()) {
      System.out.println(p + ": " + p.getRank());
    }
    
    // Aaaand... go shoot eachother!
    pewpew.shoot(daniel, daan);
    pewpew.shoot(youri, daan);
    pewpew.shoot(tim, daan);
    pewpew.shoot(youri, tim);
    pewpew.shoot(youri, daniel);
    pewpew.shoot(daan, jellis);
    pewpew.shoot(tim, jellis);
    pewpew.shoot(jellis, youri);
    
    // Checking if shots have been recorded properly
    System.out.println("\nTHESE ARE THE RESULTS OF THE SHOOTOUT:");
    for(Player p : pewpew.getRankedPlayers()) {
      System.out.print("\n" + p + ": ");
      for(Player q : pewpew.getPlayerGraph().getAdjacentVertices(p)) {
        System.out.print(q + ", ");
      }
    }
    
    // Checking if the amount of hits each player took, is correct
    System.out.println("\nTHE AMOUNT OF HITS EACH PLAYER TOOK:");
    for(Player p : pewpew.getRankedPlayers()) {
      System.out.print("\n" + p + ": ");
      System.out.print(p.getKilledAmount());
    }
    
    //Calculate new rankings and print
    pewpew.calculateRanking(20);
    
    System.out.println("\nNEW RANKINGS:");
    double totalrank = 0;
    for(Player p : pewpew.getRankedPlayers()) {
      System.out.println(p + ": " + p.getRank());
      
    }
    
    
  }
}
