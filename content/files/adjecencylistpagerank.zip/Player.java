
/**
 * Represents a Player with name, rank, the amount of other
 * players that died by Player's hand (killsAmount) and the amount
 * of Player deaths (killedAmount)
 * hashCode() and equals() are based on playerName, which very
 * conveniently provides overridden versions of theses already.
 * 
 * @author daan
 */
public class Player {
  
  private String playerName;
  private int killedAmount;
  private int killsAmount;
  private double rank;
  
  public Player(String s) {
    killedAmount = 0;
    rank = 1;
    playerName = s;
  }
  
  public String getName() {
    return playerName;
  }
  
  public void setName(String s) {
    playerName = s;
  }
  
  public double getRank() {
    return rank;
  }
  
  public void setRank(double r) {
    rank = r;
  }
  
  public int getKilledAmount() {
    return killedAmount;
  }
  
  public void setKilledAmount(int k) {
    killedAmount = k;
  }
  
  public int getKillsAmount() {
    return killsAmount;
  }
  
  public void setKillsAmount(int k) {
    killsAmount = k;
  }

  public boolean equals(Object o) {
    return this.getName().equals(((Player)o).getName());
  }
  
  public int hashCode() {
    return this.getName().hashCode();
  }

  public String toString() {
    return playerName;
  }
}
