
import java.util.Comparator;


/**
 * Compares players based on their names
 * 
 * @author daan
 */
public class NameComparator implements Comparator<Player> {
  
  public int compare(Player a, Player b) {
    return a.getName().compareTo(b.getName());
  }
}
