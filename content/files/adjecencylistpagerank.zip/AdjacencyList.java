
import java.util.Set;
import java.util.HashMap;
import java.util.HashSet;


/**
 * My own interpretation of an Adjacency List, using Generics.
 * Uses HashMap and HashSet.
 *
 * @author daan
 */
public class AdjacencyList<E> {
  /**
   * The Adjacency List consists of a HashMap in which the keys are the Vertices
   * and the values are HashSets containing Vertices adjacent to the Vertex in key.
   * Previous versions used TreeMap containing TreeSet as value providing easy
   * sorting based on playername (in the applied case), but as sorting will
   * only be done sporadically, I went for the Hash-versions because of better
   * guaranteed Time Complexity for inserts (put()) and lookups (get()):
   * Closer to O(1) than to O(n), which beats O(log n) for TreeMap
   */ 
  
  private HashMap<E, HashSet<E>> vertices = new HashMap<E, HashSet<E>>();
  
    
  // Adds new vertex "key" to graph
  public void addVertex(E key) {
    // Also adds HashSet for storing adjacent Vertices
    vertices.put(key, new HashSet<E>());
  }
  
  // Removes vertex "key" from graph
  public void removeVertex(E key) {
    vertices.remove(key);
  }
  
  // Returns Set of vertices in graph
  public Set<E> getVertices() {
    return vertices.keySet();
  }
  
  // Returns Collection (HashSet) of vertices that are adjacent to vertex "key" (outbound links)
  public HashSet<E> getAdjacentVertices(E key) {
    return vertices.get(key);
  }
  
  // Adds an adjacent vertex "element" to vertex "key" ("element" is now adjacent to "key")
  public void addAdjacentVertex(E key, E element) {
    HashSet<E> adjacentVertices = this.getAdjacentVertices(key);
    adjacentVertices.add(element);
  }
  
  // Checks if a vertex is adjacent to another vertex
  public boolean isAdjacent(E sourceVertex, E targetVertex) {
    HashSet<E> adjacentVertices = this.getAdjacentVertices(sourceVertex);
    return adjacentVertices.contains(targetVertex);
  }
  
  // Returns HashSet with all vertices that to which vertex "element" is adjacent (inbound links)
  public HashSet<E> getLinkedVertices(E element) {
    HashSet<E> linkedVertices = new HashSet<E>();
    for(E vertex : vertices.keySet()) {
      if(this.isAdjacent(vertex, element)) {
        linkedVertices.add(vertex);
      }
    }
    
    return linkedVertices;
  }
  
  // Returns number of adjacent vertices to vertex "key" (number of outbound links)
  public int getAdjecentAmount(E key) {
    return vertices.get(key).size();
  }

  // Returns number of vertices to which vertex "element" is adjacent (number of inbound links)
  public int getLinkedAmount(E element) {
    return getLinkedVertices(element).size();
  }
}
