
import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;

/**
 * Representation of a game with a collection of players
 * that can shoot at each other
 * 
 * @author daan
 */
public class Game {
  private AdjacencyList<Player> playerGraph = new AdjacencyList<Player>();

  // Returns player graph
  // Players are vertices, with edges in between, presented as an AdjacencyList
  public AdjacencyList<Player> getPlayerGraph() {
    return playerGraph;
  }

  // Returns players in the game as a Set
  public Set<Player> getPlayers() {
    return playerGraph.getVertices();
  }
  
  // Returns players in the game, sorted based on ranking
  public ArrayList<Player> getRankedPlayers() {
    RankComparator c = new RankComparator();
    ArrayList<Player> rankedPlayers = new ArrayList<Player>();
    rankedPlayers.addAll(playerGraph.getVertices());
    Collections.sort(rankedPlayers, c);
    
    return rankedPlayers;
  }
  
  // Adds a player to the game
  public void addPlayer(Player p) {
    playerGraph.addVertex(p);
  }
  
  // Let's Player "source" shoot at Player "target"
  public void shoot(Player source, Player target) {
    playerGraph.addAdjacentVertex(source, target);
    // Because the game doesn't want to factor in Players shooting other Players more than once,
    // we can't simply add 1 to the amount of kills and killed for the source
    // and target player. Instead, we set the fields with help from the AdjacencyList helper methods
    target.setKilledAmount(playerGraph.getLinkedAmount(target));
    source.setKillsAmount(playerGraph.getAdjecentAmount(source));
  }
  
  // Recalculates Ranking
  // You have to supply the amount of iterations it should calculate
  public void calculateRanking(int iterations) {
    // Calculate as many times as iterations tells us
    for(int i = 1;i <= iterations;i++) {
      double totalrank = 0;
      // Go over the players in the game
      System.out.println("\n\n");
      for(Player p : this.getPlayers()) {
        
        System.out.print("Calculating rank for: " + p.getName() + "(");
        double rank = 0;
        // Per player go over the adjacent players (Players that have been shot at)
        for(Player q : playerGraph.getAdjacentVertices(p)) {
          // Add to the rank of the shooter, the vicim's rank, divided by the amount of times
          // that player has been shot. (If the victim has been shot more, that makes him a worse
          // player, so his rank should count less in calculating the shooter's rank)
          double r = (q.getRank() / (double)q.getKilledAmount());
          rank += r;
        }
        System.out.print(rank + ")\n");
        p.setRank(rank);
        totalrank += rank;
      }
      System.out.println("\nTotal Rank: " + totalrank);
    }
  }

}
