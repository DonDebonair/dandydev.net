import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;

public class Calories {
	public static void main(String[] args) {
		HashMap<Integer, String> activities = new HashMap<Integer, String>();
		
		// Get activities
		try {
			activities = parseStdin();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Find subsets
		ArrayList<Integer[]> allSubSets = findSubsets(activities.keySet());
		
		if (allSubSets != null) {
			int count = 0;
			for (Integer[] subset : allSubSets) {
				System.out.println("\nSubset " + (++count) + ": ");
				ArrayList<String> a = new ArrayList<String>();
				for (int j = 0; j < subset.length; j++) {
					a.add(activities.get(subset[j]));
				}
				Collections.sort(a);
				for (String s : a) {
					System.out.println(s);
				}
			}
		} else {
			System.out.println("No solution");
		}

	}

	// Read contents from stdin and parse as per instructions
	// Basic exception handling, assuming input file will
	// be proper :)
	public static HashMap<Integer, String> parseStdin() throws Exception {
		HashMap<Integer, String> activities = new HashMap<Integer, String>();
		Console c = System.console();
		
		ArrayList<String> lines = new ArrayList<String>();

		int itemcount = 0;
		String n = c.readLine("Please enter number of activities: ");
		if((itemcount = Integer.parseInt(n)) > 0) {
			for(int i = 1;i <= itemcount;i++) {
				lines.add(c.readLine("Activity " + i + ": "));
			}
			
			for(String l : lines) {
				String[] s = l.split("\\s");
				String activity = s[0];
				Integer calories = Integer.valueOf(s[1]);
				activities.put(calories, activity);
			}
		} else {
			throw new Exception("Number of activities must be a positive integer!");
		}
		
		return activities;
	}
	
	// returns the sum of the values in the given array
	public static int sum(Integer[] array) {
		int sum = 0;
		
		for (int i = 0; i < array.length; i++) {
			sum += array[i];
		}

		return sum;
	}

	// returns a string with n copies of the given character
	public static String makeString(int n, char ch) {
		String s = "";
		
		for (int i = 0; i < n; i++) {
			s += ch;
		}

		return s;
	}

	// returns the number of times that the given character appears in the given
	// string. Helper for the allOnes() method
	public static int count(String s, char ch) {
		int count = 0;
		
		while (s.indexOf(ch) != -1) {
			count++;
			s = s.substring(s.indexOf(ch) + 1);
		}
		return count;
	}

	// returns true if the given string consists only of 1's
	// to see if we reached the highest binary number
	public static boolean allOnes(String s) {
		return count(s, '1') == s.length();
	}

	// returns a new string based on the given one, but with the ith char
	// replaced by the given char. Helper for nextBinary()
	public static String setChar(String s, int i, char ch) {
		return s.substring(0, i) + ch + s.substring(i + 1);
	}

	// given a string containing a binary number,
	// returns a string containing the next higher binary number.
	// for example, nextBinary("10011") -> "10100"
	// assume not all 1's
	public static String nextBinary(String num) {
		int index = num.length() - 1;
		
		while (num.charAt(index) == '1')
		{
			num = setChar(num, index, '0');
			index--;
		}
		return setChar(num, index, '1');
	}

	// given a set and a binary number of the same length,
	// returns an array whose values correspond to the values in the set,
	// where the binary number contains a 1.
	// Kind of matching the binary pattern
	public static Integer[] makeSubset(Integer[] set, String binary) {
		Integer[] subset = new Integer[count(binary, '1')];
		int subsetIndex = 0;
		
		for (int i = 0; i < set.length; i++) {
			if (binary.charAt(i) == '1') {
				subset[subsetIndex] = set[i];
				subsetIndex++;
			}
		}
		return subset;
	}

	// returns all subsets of the given set, whose values add up to 0.
	// returns null, if no such subset
	public static ArrayList<Integer[]> findSubsets(Collection<Integer> c) {
		// need a string of same length as set, that consists of 00..01
		
		Integer[] set = new Integer[c.size()];
		set = c.toArray(set);
		
		ArrayList<Integer[]> subSets = new ArrayList<Integer[]>();
		String binary = makeString(set.length, '0');

		while (!allOnes(binary)) {
			binary = nextBinary(binary);
			Integer[] subset = makeSubset(set, binary);


			if (sum(subset) == 0) {
				subSets.add(subset);
			}
		}
		
		if(subSets.isEmpty()) {
			return null;
		} else {
			return subSets;
		}
	}
}